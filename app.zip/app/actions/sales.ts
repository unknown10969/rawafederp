"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";

export async function createSale(_prev: unknown, formData: FormData) {
  const productId = formData.get("productId") as string;
  const quantity = parseFloat((formData.get("quantity") as string) || "0");
  const unitPrice = parseFloat((formData.get("unitPrice") as string) || "0");

  if (!productId || quantity <= 0 || unitPrice < 0) {
    return { error: "Product, quantity (positive), and unit price are required." };
  }

  const totalAmount = quantity * unitPrice;

  try {
    await prisma.sale.create({
      data: { productId, quantity, unitPrice, totalAmount },
    });
    revalidatePath("/sales");
    revalidatePath("/dashboard");
    redirect("/sales");
  } catch (e) {
    const message = e instanceof Error ? e.message : "Failed to record sale.";
    return { error: message };
  }
}
