import { PageHeader } from "@/components/page-header";
import { prisma } from "@/lib/db";
import { DollarSign, TrendingUp, TrendingDown, AlertTriangle, LucideIcon } from "lucide-react";
import Link from "next/link";

async function getDashboardMetrics() {
  try {
    const [revenueResult, purchaseExpenseResult, otherExpenseResult, alertCount] = await Promise.all([
      prisma.sale.aggregate({ _sum: { totalAmount: true } }),
      prisma.purchase.aggregate({ _sum: { totalAmount: true } }),
      prisma.expense.aggregate({ _sum: { amount: true } }),
      prisma.lowStockAlert.count({ where: { isResolved: false } }),
    ]);

    const revenue = Number(revenueResult._sum.totalAmount ?? 0);
    const purchaseCosts = Number(purchaseExpenseResult._sum.totalAmount ?? 0);
    const otherExpenses = Number(otherExpenseResult._sum.amount ?? 0);
    const expenses = purchaseCosts + otherExpenses;
    const profit = revenue - expenses;

    return { revenue, expenses, profit, alertCount };
  } catch {
    return { revenue: 0, expenses: 0, profit: 0, alertCount: 0 };
  }
}

function MetricCard({
  title,
  value,
  icon: Icon,
  variant = "default",
}: {
  title: string;
  value: string;
  icon: LucideIcon;
  variant?: "default" | "positive" | "negative";
}) {
  const variantStyles = {
    default: "border-border bg-card text-card-foreground",
    positive: "border-emerald-500/30 bg-emerald-500/5 text-emerald-400",
    negative: "border-red-500/30 bg-red-500/5 text-red-400",
  };

  return (
    <div
      className={`rounded-xl border p-6 shadow-sm transition-shadow hover:shadow-md cursor-pointer ${variantStyles[variant]}`}
    >
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <Icon className="h-8 w-8 text-muted-foreground/60" />
      </div>
      <p className="mt-3 text-2xl font-bold tracking-tight">{value}</p>
    </div>
  );
}

function formatCurrency(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n);
}

export default async function DashboardPage() {
  const { revenue, expenses, profit, alertCount } = await getDashboardMetrics();

  return (
    <>
      <PageHeader
        title="Dashboard"
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Dashboard" }]}
      />
      <div className="p-6">
        {/* Bento grid */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Revenue"
            value={formatCurrency(revenue)}
            icon={DollarSign}
            variant="default"
          />
          <MetricCard
            title="Expenses"
            value={formatCurrency(expenses)}
            icon={TrendingDown}
            variant="negative"
          />
          <MetricCard
            title="Profit"
            value={formatCurrency(profit)}
            icon={TrendingUp}
            variant={profit >= 0 ? "positive" : "negative"}
          />
          <Link href="/alerts">
            <MetricCard
              title="Low Stock Alerts"
              value={alertCount.toString()}
              icon={AlertTriangle}
              variant={alertCount > 0 ? "negative" : "default"}
            />
          </Link>
        </div>
        {/* Optional: wide summary card */}
        <div className="mt-6 rounded-xl border border-border bg-card p-6">
          <h2 className="text-sm font-medium text-muted-foreground">Summary</h2>
          <p className="mt-2 text-muted-foreground">
            Revenue from sales, expenses from purchases and other costs. Profit = Revenue − Expenses.
            {alertCount > 0 && (
              <span className="block mt-2 text-red-400">
                ⚠️ {alertCount} low stock alert{alertCount > 1 ? "s" : ""} require attention.
              </span>
            )}
          </p>
        </div>
      </div>
    </>
  );
}
