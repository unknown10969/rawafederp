import { PageHeader } from "@/components/page-header";
import { prisma } from "@/lib/db";
import { CreatePurchaseForm } from "../create-purchase-form";

export default async function NewPurchasePage() {
  const products = await prisma.product.findMany({
    orderBy: { name: "asc" },
  });

  return (
    <>
      <PageHeader
        title="Log Purchase"
        breadcrumbs={[
          { label: "Home", href: "/dashboard" },
          { label: "Purchases", href: "/purchases" },
          { label: "Add New" },
        ]}
      />
      <div className="p-6 max-w-lg">
        <CreatePurchaseForm products={products} />
      </div>
    </>
  );
}
