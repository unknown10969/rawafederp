import { PageHeader } from "@/components/page-header";
import { prisma } from "@/lib/db";
import { CreateSaleForm } from "../create-sale-form";

export default async function NewSalePage() {
  const products = await prisma.product.findMany({
    orderBy: { name: "asc" },
  });

  return (
    <>
      <PageHeader
        title="Record Sale"
        breadcrumbs={[
          { label: "Home", href: "/dashboard" },
          { label: "Sales", href: "/sales" },
          { label: "Add New" },
        ]}
      />
      <div className="p-6 max-w-lg">
        <CreateSaleForm products={products} />
      </div>
    </>
  );
}
